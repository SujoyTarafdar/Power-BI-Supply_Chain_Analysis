# Data-analysis-projects-using-Power-BI

Data cleaned, Done with data modelling, Using DAX formulaes created useful measures, created interactive dashboards and driven useful insights.

Sales Dashboard :

![WhatsApp Image 2024-04-17 at 11 05 35 AM](https://github.com/Anusha-11111/Data-analysis-projects-using-Power-BI/assets/112841894/9a99300e-47d2-47ff-8d9d-c8ca20a8ee11)

Supply chain analytics dashboard:

![WhatsApp Image 2024-04-17 at 11 06 32 AM](https://github.com/Anusha-11111/Data-analysis-projects-using-Power-BI/assets/112841894/e15cb6c3-8bf4-4eb9-a228-2fa4f5300ebc)



